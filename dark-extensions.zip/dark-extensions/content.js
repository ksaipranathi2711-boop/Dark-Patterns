const darkPatternKeywords = [
  "accept all cookies",
  "auto-renew",
  "hidden fees",
  "limited offer",
  "last chance",
  "hard to cancel",
  "subscribe",
  "tracking"
];

const pageText = document.body.innerText.toLowerCase();

const detected = darkPatternKeywords.filter(k =>
  pageText.includes(k)
);

if (detected.length > 0) {
  alert(
    "⚠️ Dark Patterns Detected:\n\n" +
    detected.join("\n")
  );
}
